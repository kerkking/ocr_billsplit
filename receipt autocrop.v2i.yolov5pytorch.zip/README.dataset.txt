# receipt autocrop > 2025-07-18 10:11pm
https://universe.roboflow.com/ocrreceipts/receipt-autocrop

Provided by a Roboflow user
License: CC BY 4.0

